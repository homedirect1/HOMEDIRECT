<?php

/**
 * CedCommerce
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End User License Agreement (EULA)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://cedcommerce.com/license-agreement.txt
 *
 * @category    Ced
 * @package     Ced_CsHyperlocal
 * @author    CedCommerce Core Team <connect@cedcommerce.com>
 * @copyright   Copyright CedCommerce (https://cedcommerce.com/)
 * @license      https://cedcommerce.com/license-agreement.txt
 */

namespace Ced\CsHyperlocal\Block\Link;

/**
 * Block representing link with two possible states.
 * "Current" state means link leads to URL equivalent to URL of currently displayed page.
 *
 * @method string                          getLabel()
 * @method string                          getPath()
 * @method string                          getTitle()
 * @method null|bool                       getCurrent()
 * @method \Magento\Framework\View\Element\Html\Link\Current setCurrent(bool $value)
 */
class Current extends \Ced\CsMarketplace\Block\Link\Current
{
    /**
     * Default path
     *
     * @var \Magento\Framework\App\DefaultPathInterface
     */
    protected $_defaultPath;

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Framework\App\DefaultPathInterface $defaultPath
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\DefaultPathInterface $defaultPath,
        \Ced\CsMarketplace\Helper\Data $marketplaceHelper,
        array $data = []
    ) {
        parent::__construct($context,$defaultPath, $data);
        $this->_defaultPath = $defaultPath;
        $this->marketplaceHelper = $marketplaceHelper;
    }

    /**
     * Render block HTML
     * @return string
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    protected function _toHtml()
    {
        if (false != $this->getTemplate()) {
            return parent::_toHtml();
        }

        /** check if distance type filter enable */
        $filterType = $this->marketplaceHelper->getStoreConfig(\Ced\CsHyperlocal\Helper\Data::FILTER_TYPE);
        if ($this->getName() == 'ced_hyperlocal' && $filterType == 'distance')
            return false;


        $highlight = '';
        if ($this->isCurrent()) {
            $highlight = ' active';
        }

        if (0) {
            $html = '<li id="'.$this->escapeHtml((string)new \Magento\Framework\Phrase($this->getName())).'" class="nav item">';
            $html .= '<i class="'.$this->escapeHtml((string)new \Magento\Framework\Phrase($this->getFontAwesome())).'"></i>';
            $html .= '<span><strong style="margin-left: 3px;">'
                . $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getLabel()))
                . '</strong></span>';


            $childHtml = $this->getChildHtml();
            if(strlen($childHtml) > 0) {
                $html .= '<span class="fa arrow"></span>';
            }

            if(strlen($childHtml) > 0) {
                $html .= $childHtml;
                $html .= '<div class="largeview-submenu">';
                $html .= $childHtml;
                $html .= '</div>';
            }

            $html .= '</a>';
            $html .= '</li>';
        } else {
            $html = '<li id="'.$this->escapeHtml((string)new \Magento\Framework\Phrase($this->getName())).'" class="nav item"><a class="' . $highlight . '" href="' . $this->escapeHtml($this->getHref()) . '"';
            $html .= $this->getTitle()
                ? ' title="' . $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getTitle())) . '"'
                : '';
            $html .= '>';
            $html .= '<i class="'.$this->escapeHtml((string)new \Magento\Framework\Phrase($this->getFontAwesome())).'"></i>';

            if ($this->getIsHighlighted() || strlen($highlight) > 0) {
                $html .= '<span><strong style="margin-left: 3px;">';
            } else {
                $html .= '<span style="margin-left: 3px;">';
            }

            $html .= $this->escapeHtml((string)new \Magento\Framework\Phrase($this->getLabel()));

            if ($this->getIsHighlighted() || strlen($highlight) > 0) {
                $html .= '</strong></span>';
            } else {
                $html .= '</span>';
            }

            $childHtml = '';
            $childHtml = $this->getChildHtml();
            if(strlen($childHtml) > 0) {
                $html .= '<span class="fa arrow"></span>';
            }

            $html .= '</a>';

            if(strlen($childHtml) > 0) {
                $html .= $childHtml;
                $html .= '<div class="largeview-submenu">';
                $html .= $childHtml;
                $html .= '</div>';
            }
            $html .= '</li>';
        }

        return $html;
    }
}
