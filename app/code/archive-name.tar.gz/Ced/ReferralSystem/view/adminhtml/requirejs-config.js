var config = {
    config: {
      mixins: {
        'mage/validation': {
          'Ced_ReferralSystem/js/validation-mixin': true
        }
      }
    }
  }