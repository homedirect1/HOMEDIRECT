<?php
/**
 * CedCommerce
  *
  * NOTICE OF LICENSE
  *
  * This source file is subject to the End User License Agreement (EULA)
  * that is bundled with this package in the file LICENSE.txt.
  * It is also available through the world-wide-web at this URL:
  * http://cedcommerce.com/license-agreement.txt
  *
  * @category    Ced
  * @package     Ced_CsAdvTransaction
  * @author   	 CedCommerce Core Team <connect@cedcommerce.com >
  * @copyright   Copyright CEDCOMMERCE (http://cedcommerce.com/)
  * @license      http://cedcommerce.com/license-agreement.txt
  */
namespace Ced\CsAdvTransaction\Controller\Adminhtml\Pay;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
class NewAction extends \Magento\Backend\App\Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }
    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        
    	$postData = $this->getRequest()->getPostValue();
    	$vid = $this->getRequest()->getParam('vendor_id');
    	if(!isset($postData['eligible_orders']))
    	{
    		$this->_redirect('csadvtransaction/pay/order',['vendor_id',$vid]);
    	}
    	
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Ced_CsAdvTransaction::manage_vendor_advtransaction');
        $resultPage->getConfig()->getTitle()->set(__('Pay to vendor'));
        return $resultPage;
    }
}